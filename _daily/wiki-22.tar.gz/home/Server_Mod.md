---
title: Welcome Page
description: 
published: true
date: 2021-01-11T23:38:58.451Z
tags: 
editor: markdown
---

# Welcome
This is the BeamMP Wiki!

Navigate using the tabs on the left - whilst some pieces of the Wiki are still under construction, you will be able to find all of the information you need to get the mod up and running, as well as a server.

Any questions or issues? Please had over to our forum and make a post, our community will be able to help :)