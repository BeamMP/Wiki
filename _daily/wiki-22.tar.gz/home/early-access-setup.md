---
title: Early Access Setup
description: How to setup Early Access
published: true
date: 2021-11-07T21:22:20.620Z
tags: 
editor: markdown
dateCreated: 2021-01-16T19:48:17.235Z
---

# Adding the Early Access Group Title!
Firstly thank you for supporting the mod!

Please note you must use the same email to make a account on the fourms as on patreon.

First click here so that we can edit your profile.

![profile.png](/profile.png)

Next you will be presented with a page similar to this:
![groupup.png](/groupup.png)

From here you can see the groups that you are a part of and that you can proudly show off.
To select one just click on the title button then click one from there. 

Once done click save on the bottom.
Thats it :)

# What Are the Perks of Early Access?
You may be wondering whats included in Early Access, After you've linked your Discord and Forum account, you should be able to take full advantage of these perks. 

The things included are as follows:

- Exclusive access to our EA Discord Channels.

- Access to BeamMP Pre Release Server and Client Builds.

- An Early Access in-game badge.




