---
title: Avantages Early Access
description: Comment profiter des avantages Early Access
published: true
date: 2021-04-22T12:20:24.787Z
tags: 
editor: markdown
---

# Ajouter le prefix Early Access en jeu
Tout d'abord, merci de supporter le projet !

Dans un premier temps, rendez-vous dans Edit Profile
![select-edit-profile-forum.png](/select-edit-profile-forum.png)

Vous devriez voir une paga similaire à celle-ci
![select-group-title-forum.png](/select-group-title-forum.png)

Ici vous pourrez voir tous les groupes auxquels vous appartenez et que vous pouvez montrer en jeu. Pour changer votre prefix, il vous suffit simplement de cliquer sur le groupe que vous souhaitez utiliser. Si vous voulez afficher plusieurs groupes sur le forum vous pouvez en selectionner plusieurs en restant appuyé sur la touche SHIFT.

Une fois cela fait, cliquez sur Save en bas à droite.