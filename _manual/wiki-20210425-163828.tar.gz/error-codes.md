---
title: Error Codes & Meanings
description: This page is for the error codes that exist within our application. We will likely have the meaning and a possible solution to your issue.
published: true
date: 2021-01-24T15:20:07.508Z
tags: error, code
editor: markdown
---

> For any other issues not on this list, you can refer to https://docs.microsoft.com/en-us/windows/win32/winsock/windows-sockets-error-codes-2 if you know a bit about how networks / sockets work.
{.is-warning}

# Launcher Error Codes
Below is a list of all the Launcher Error Codes, what they mean & how to solve them in most cases.
If the launcher starts but encounters random errors they should be reported

> Note: If the launcher closes immediately check the log you will find startup error codes
{.is-info}

> If the launcher gets stuck updating that means it requires administrator privileges or you need to update manually, sometimes the antivirus may block downloads as well
{.is-info}

`Code 2`
- The process that executed the launcher is no longer valid the user should try launching the launcher from where they installed it

`Code 3`
- The process that executed the launcher is valid but it's not an exe

`Code 4`
- The process that executed the launcher is valid but it's not explorer or cmd

`Logger file init failed`
- The launcher doesn't have the ability to create files, Launching as admin could fix the issue

`Sorry Backend System Outage! Don't worry it will back on soon!`
- The Backend did not respond could be the firewall or ISP

`Primary Servers Offline! sorry for the inconvenience!`
- The Launcher failed to check for an update firewall or ISP

`Launcher Update failed!`
- The launcher failed to download the new version

`Cannot Create BeamNG Directory! Retrying...`
- The launcher cannot create the BeamNG folder it will automatically relaunch requesting admin after 3 secs

`Please close the game and try again`
- This error will happen if the game is already running under the same profile / launcher was unable to reset the folder

`Cannot Create Mods Directory! Retrying...`
- The launcher cannot create the Mods folder it will automatically relaunch requesting admin after 3 secs

`Cannot Create Settings Directory! Retrying...`
- The launcher cannot create the Settings folder it will automatically relaunch requesting admin after 3 secs

`Please launch the game at least once`
- This will happen when the launcher tries to modify the game's profile directory and fails. Launching the game should fix it

`Failed to launch the game`
- This will happen when the game refused to update the profile directory

`Failed to Launch the game! launcher closing soon`
- Launcher failed to start the game launching the game once before retrying could fix it

`Game Closed! launcher closing soon`
- This will happen after the launcher was able to start the game and shouldn't happen unless the game failed to start or closed

`Mod did not load! launcher closing soon`
- This will happen when the mod was found not  loaded by the game for 35 secs that should only happen if beamng is corrupted or when someone is attempting to load their own system

`Failed to find the game please launch it. Report this if the issue persists`
- Code 1 means that the launcher was unable to find the game under Steam a potential fix would be to reinstall or launch the game, also you might want to set Steam to online mode
- Code 2 means the same except the launcher was unable to find the game ID under Steam
- Code 3 means that the launcher was unable to find the game's info (where it last started version ect...)
- Code 4 means the same except the launcher was unable to open the location where those values should be
- Code 5 means that the game runtime files were not found if after launching the game it still doesn't work then report the error

`Sorry. We do not support cracked copies report this if you believe this is a mistake`
- Code 1  means that steam was found but not where it's installed this could be fixed by just running steam or reinstalling steam.
- Code 2 means that the game ID was not found under the steam directory.
- Code 3 means that the steam directory where the game ID would be was not found.
- Code 4 means that steam was not installed/Not found.
- Code 5 means that the game was not installed in a steamapps folder meaning it was moved manually.
- Code 6 means that the launcher was unable to link a steam ID to the last steam ID the game was launched from could be that the user doesn't own the game (borrow). (Make sure he redownloads the launcher to make sure it doesn't fix itself)

`Illegal steam modifications detected report this if you believe this is a mistake`
- Code 1 means that the launcher found illegal files in the steam directory


# Other Error Codes (Server and Launcher)
Below is a list of all the Server Error Codes, what they mean & how to solve them in most cases.

> Note: If the server closes immediately check the log you will find startup error codes
{.is-info}

`Code 10060`
- There is an issue with your ports. Please check you have port forwarded and opened it on incoming on your firewall

`Code 10022`
- This is an issue with binding to the port. Check if the port is in use or use a different port

`Code 10048`
- address already in use, another BeamMP server or program is already running on that port

`Code 10051`
- bad port forwarding or other similar "unreachable" issue - verify that its all setup properly

`Code 10052`
- network reset, happens if the network drops connection while a connection is being established. should never happen. just retry

`Code 10053`
- connection aborted, timeout or other network error, just retry

`Code 10054`
- on launcher: server closed
- on server: client disconnected

`Code 10060`
- network timed out, on launcher, this usually means that the server wasnt port forwarded properly

`Code 10061`
- same as 10060

`Code 10064`
- unlikely error, but it means that the host died, so server shutdown or ports were closed, connection died some other way

`Code 10065`
- host not reachable: no internet or bad port forwarding, or any other similar issue*