---
title: Early Access Setup
description: How to setup Early Access
published: true
date: 2021-04-22T12:16:37.788Z
tags: 
editor: markdown
---

# Adding the Early Access Group Title!
Firstly thank you for supporting the mod!

Firstly click here so that we can edit your profile.
![select-edit-profile-forum.png](/select-edit-profile-forum.png)

Next you will be presented with a page similar to this:
![select-group-title-forum.png](/select-group-title-forum.png)

From here you can see the groups that you are a part of and that you can proudly show off.
To select one just click on it. If you want to show multiple at the same time press and hold CTRL on your keyboard and then click on the ones you want.

Once done click save in the bottom right corner.
Thats it :)